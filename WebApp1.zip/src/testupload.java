

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import App1.Employee;
import App1.EmployeeDAOImplem;

@WebServlet("/testupload")
public class testupload extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public testupload() {
        super();

    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw= response.getWriter();
			String ss = request.getParameter("file");
			ArrayList<Employee> allemployeescsv = new ArrayList<Employee>();
			System.out.println(ss);
			FileReader fr= new FileReader(ss);
			 BufferedReader r= new BufferedReader(fr);
			 String s= r.readLine();
			 s=replacedoublequotes(r.readLine());
			 
			 String sa[]=null;
			 while(s!=null)
			 {
				
				 sa= s.split(",");
				 Employee e = new Employee();
			
				 e.setEmployeeId(Integer.parseInt(sa[0]));
				 e.setFirstName(sa[1]);
				 e.setLastName(sa[2]);
				 e.setEmail(sa[3]);
				 e.setEmp_phoneno(sa[4]);
				 e.setHire_date(sa[5]);
				 e.setEmp_jobtype(sa[6]);
				 e.setEmp_salary(Float.parseFloat(sa[7]));
				 e.setEmp_commission(Float.parseFloat(sa[8]));
				 e.setEmp_managerid(Integer.parseInt(sa[9]));
				 e.setEmp_dept(Integer.parseInt(sa[10]));
				 e.setEmp_password("abcd");
				 e.setEmp_type(0);
				 allemployeescsv.add(e);
				 s=replacedoublequotes(r.readLine());
				 
			 }
			 EmployeeDAOImplem ed= new EmployeeDAOImplem();
			 try {
				if(ed.uploadCSV(allemployeescsv)==1) {
					
					   pw.println("<script type=\"text/javascript\">");
					   pw.println("alert('Added Employees Succesfully');");
					   pw.println("location='adminlogin.jsp';");
					   pw.println("</script>");
				}
				else {
					   pw.println("<script type=\"text/javascript\">");
					   pw.println("alert('oops! Couldnt add Employees');");
					   pw.println("</script>");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	protected String replacedoublequotes(String a) {
		if(a!=null) {
		a= a.replaceAll("\"", "");}
		return a;
	}

}
