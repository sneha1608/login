package App1;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/afterlogin")
public class afterlogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public afterlogin() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		String name= request.getParameter("email");
		String password =request.getParameter("pass");
	
		EmployeeDAOImplem em1 = new EmployeeDAOImplem();
		try {
			System.out.println(em1.fetchLoginUser(name, password));
			if(em1.fetchLoginUser(name, password)==0)
			{
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Ooop! email and password doesnt match');");
				pw.println("location='login.html';");
				pw.println("</script>");
			}
			else
			{
				HttpSession hs = request.getSession();
				hs.setAttribute("emp_name", name);
			
				//if employee redirect to employee dashboard
				if(em1.fetchEmpType(name)==0) {
					response.sendRedirect("employeeDashboard.jsp");
				}
				else if(em1.fetchEmpType(name)==1) {

					String[] s= name.split("@",0);
					response.sendRedirect("adminlogin.jsp");
					pw.println("Hello "+ s[0]+ "</br>" + "login succesfull"+"</br>"+"Welcome back to wesbite development" );
					pw.print("<html></br></br><center><img src=\"https://media2.giphy.com/media/SggILpMXO7Xt6/source.gif\" title=\"this slowpoke moves\" /></center></html>");
					pw.print("<html></br></br><center><form action=\"registration.jsp\" method=\"post\"><input type=\"submit\" value=\"INSERT\" ></form></center></html>");
					pw.print("<html></br></br><center><form action=\"deleteServlet\" method=\"post\"><input type=\"hidden\" name=\"del\"  value=\"1\"><input type=\"submit\" value=\"DELETE\"></form></center></html>");

				}
					
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
