package App1;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/deleteServlet")
public class deleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public deleteServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String empid1= request.getParameter("del");
		PrintWriter pw= response.getWriter();
		if(empid1.equals("1"))
		{
		
		pw.println("<html><body><form action=\"\" method=\"post\"><input type=\"text\" name=\"delteemp\"> <input type=\"hidden\" name=\"del\"  value=\"2\"><input type=\"submit\" value=\"DELTE\"></form><body></html>");
		
		}
		
		else if(empid1.equals("2")) {
		int empid=	Integer.parseInt(request.getParameter("delteemp"));
		EmployeeDAOImplem em = new EmployeeDAOImplem();
		try {
			//em.delete(empid);
			
			if(em.delete(empid)==1)
			{
				pw.print("<html><body><h1>Deleted Succesfully</h1></body></html>");
				pw.println("empid: "+empid );
			}
			else
			{
				pw.println("<html><body><h1>Deletion unSuccesfull</h1></body></html>");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}

}
