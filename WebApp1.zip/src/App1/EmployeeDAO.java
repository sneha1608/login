package App1;
import java.util.ArrayList;

public interface EmployeeDAO {
	public int delete(int id) throws Exception;
	public int insert(Employee e) throws Exception;
	
	public ArrayList<String> fetchDepartment() throws Exception;
	public ArrayList<String> fetchJobs() throws Exception;
	
	public int fetchDepartmentID(String deptName) throws Exception;
	public String fetchDepartmentName(int deptID) throws Exception;
	public String fetchJobID(String jobName) throws Exception;	
	public String fetchJobName(String jobID) throws Exception;
	public int fetchUser(int id) throws Exception;
	
	public int fetchLoginUser(String email, String password) throws Exception;
	
	public int fetchEmpType(String type) throws Exception;
	
	public Employee fetchEmployee(String email) throws Exception;
	
	public int UpdateEmployee(Employee emp) throws Exception;
	
	public int selecttotalEmployees() throws Exception;
	public int selecttotalRegions() throws Exception;
	
	public ArrayList<Employee> fetchEmployeeTabe() throws Exception; 
	
	public void exportCSV() throws Exception;
	
	public int uploadCSV(ArrayList<Employee> ar) throws Exception;
}
