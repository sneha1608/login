package App1;
import java.sql.*; 
 import java.io.FileWriter; 
 import au.com.bytecode.opencsv.CSVWriter;
 class exportcsv {
public static void main(String args[]) throws Exception{
     Class.forName ("oracle.jdbc.driver.OracleDriver");
  
     Connection conn = DriverManager.getConnection
       ("jdbc:oracle:thin:@192.168.18.40:1521:ASCEND", "mvinay", "mvinay");
      
     
       Statement stmt = conn.createStatement();
       
         ResultSet query_set = stmt.executeQuery("select employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,commission_pct,manager_id,department_id from EMPLOYEES");
                  
           FileWriter my_csv=new FileWriter("C:\\Users\\mvinay\\Desktop\\out.csv");
           CSVWriter my_csv_output=new CSVWriter(my_csv); 
           boolean includecolumnnames=true;
           my_csv_output.writeAll(query_set,includecolumnnames);
           my_csv_output.close();
           System.out.println(my_csv_output);
    }
  }
