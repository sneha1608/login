package App1;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormatSymbols;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/addservlet")
public class addservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
    public addservlet() {
        super();

    }
    	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EmployeeDAOImplem em1 = new EmployeeDAOImplem();
		PrintWriter pw= response.getWriter();
		int empid= Integer.parseInt(request.getParameter("empid"));
		
		try {
			if(em1.fetchUser(empid)==1) {
				   pw.println("<script type=\"text/javascript\">");
				   pw.println("alert('Ooop! User already exists');");
				   pw.println("location='registration.jsp';");
				   pw.println("</script>");
			}
			else {
				AESEncyption aes= new AESEncyption();
				String lname= request.getParameter("lastname");
				String email= request.getParameter("email");
				String fname= request.getParameter("firstname");
				String hire_date = replaceDateFactors(request.getParameter("hdate")) ;
				float  emp_salary = Float.parseFloat(request.getParameter("sal"));
				float emp_commission = Float.parseFloat(request.getParameter("comm"));
				String emp_phoneno = request.getParameter("phonenum");
				int emp_managerid = Integer.parseInt(request.getParameter("manid"));
				String password = aes.encrypt(request.getParameter("pass"));
				int emptype=0;
				int emp_dept = 0;
				try {
					emp_dept = em1.fetchDepartmentID(request.getParameter("deptlist"));
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
				
				String emp_jobtype = null;
				try {
					emp_jobtype = em1.fetchJobID(request.getParameter("jobtypes"));
					
				} catch (Exception e2) {
					e2.printStackTrace();
				}
				
				
				Employee e = new Employee(empid, fname, lname, email, hire_date, emp_salary, emp_commission, emp_dept, emp_jobtype, emp_phoneno, emp_managerid,password,emptype);
				
				try {
					if(em1.insert(e)==1)
					{
						pw.print("<html><body><h1>Inserted Succesfully</h1></body></html>");
						pw.println("empid: "+empid+  "</br>fname :" +fname + "</br>lname : "+ lname + "</br>email :"+ email );
						pw.println(hire_date+"</br>");
						pw.println(emp_salary+"</br>");
						pw.println(emp_commission+"</br>");
						pw.println(emp_dept+"</br>");
						pw.println(emp_jobtype+"</br>");
						pw.println(emp_phoneno+"</br>");
						pw.println(emp_managerid+"</br>");
					}
					else
					{
						pw.println("<html><body><h1>Insertertion unSuccesfull</h1></body></html>");
					}
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
			}
		} catch (Exception e3) {
			e3.printStackTrace();
		}
		
		
	}


	private String replaceDateFactors(String newDate) {
		String newDate1 = newDate.replace("/", "-");
		String newDate2= newDate1.substring(8)+"-"+newDate1.substring(5,7)+"-"+newDate1.substring(0,4);
		String nd = new DateFormatSymbols().getMonths()[Integer.parseInt(newDate2.substring(3, 5))-1].substring(0,3);
		newDate1= newDate2.substring(8)+"-"+nd+"-"+newDate2.substring(8);
		return newDate1;
	}

}
