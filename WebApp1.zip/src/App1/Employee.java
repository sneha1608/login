package App1;
public class Employee {
	private int employeeId;
	private String firstName;
	private String lastName;
	private String email;
	private String emp_phoneno;
	private String hire_date;
	private String emp_jobtype;
	private float emp_salary;
	private float emp_commission;
	private  int emp_managerid;
	private int emp_dept;
	private String emp_password;
	private int emp_type;
	
	

	public Employee() {
		
	}
	
	public Employee(int employeeId, String firstName, String lastName, String email, String hire_date, float emp_salary,
			float emp_commission, int emp_dept, String emp_jobtype, String emp_phoneno, int emp_managerid, String emp_password,int emp_type) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.hire_date = hire_date;
		this.emp_salary = emp_salary;
		this.emp_commission = emp_commission;
		this.emp_dept = emp_dept;
		this.emp_jobtype = emp_jobtype;
		this.emp_phoneno = emp_phoneno;
		this.emp_managerid = emp_managerid;
		this.emp_password= emp_password;
		this.emp_type= emp_type;
	}
	
	public Employee(String firstName, String lastName, String email, String emp_phoneno,
			String emp_jobtype, float emp_salary, float emp_commission, int emp_managerid, int emp_dept,int employeeId) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.emp_phoneno = emp_phoneno;
		this.emp_jobtype = emp_jobtype;
		this.emp_salary = emp_salary;
		this.emp_commission = emp_commission;
		this.emp_managerid = emp_managerid;
		this.emp_dept = emp_dept;
	}

	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}



	public String getHire_date() {
		return hire_date;
	}



	public void setHire_date(String hire_date) {
		this.hire_date = hire_date;
	}



	public float getEmp_salary() {
		return emp_salary;
	}



	public void setEmp_salary(float emp_salary) {
		this.emp_salary = emp_salary;
	}



	public float getEmp_commission() {
		return emp_commission;
	}



	public void setEmp_commission(float emp_commission) {
		this.emp_commission = emp_commission;
	}



	public int getEmp_dept() {
		return emp_dept;
	}



	public void setEmp_dept(int emp_dept) {
		this.emp_dept = emp_dept;
	}



	public String getEmp_jobtype() {
		return emp_jobtype;
	}



	public void setEmp_jobtype(String emp_jobtype) {
		this.emp_jobtype = emp_jobtype;
	}



	public String getEmp_phoneno() {
		return emp_phoneno;
	}



	public void setEmp_phoneno(String emp_phoneno) {
		this.emp_phoneno = emp_phoneno;
	}



	public int getEmp_managerid() {
		return emp_managerid;
	}



	public void setEmp_managerid(int emp_managerid) {
		this.emp_managerid = emp_managerid;
	}



	public String getEmp_password() {
		return emp_password;
	}



	public void setEmp_password(String emp_password) {
		this.emp_password = emp_password;
	}




	public int getEmp_type() {
		return emp_type;
	}




	public void setEmp_type(int emp_type) {
		this.emp_type = emp_type;
	}
	
	
	
}
