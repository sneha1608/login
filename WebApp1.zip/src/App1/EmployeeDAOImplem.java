package App1;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import au.com.bytecode.opencsv.CSVWriter;

public class EmployeeDAOImplem implements EmployeeDAO {

	private static final String DRIVER_NAME = "oracle.jdbc.driver.OracleDriver";
	private static final String DB_URL = "jdbc:oracle:thin:@192.168.18.40:1521:ASCEND";
	private static final String ID = "mvinay";
	private static final String PASS = "mvinay";
	
	private static final String SELECTDEPT="SELECT DEPARTMENT_NAME FROM DEPARTMENTS order by DEPARTMENT_NAME";
	private static final String SELECTJOBS="SELECT JOB_TITLE FROM JOBS ORDER BY JOB_TITLE";
	private static final String DELETE = "DELETE FROM employees WHERE EMPLOYEE_ID=?";
	private static final String INSERT = "INSERT INTO employees VALUES(?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?)";
	private static final String SELECTDEPTID = "SELECT DEPARTMENT_ID FROM DEPARTMENTS WHERE DEPARTMENT_NAME=?";
	private static final String SELECTJOBID = "SELECT JOB_ID FROM JOBS WHERE JOB_TITLE=?";
	private static final String SELECTUSERID = "SELECT count(*) FROM EMPLOYEES WHERE EMPLOYEE_ID=?";
	private static final String SELECTLOGINID = "SELECT password FROM EMPLOYEES WHERE email=?";
	private static final String SELECTEMPTYPE = "SELECT typeinfo from EMPLOYEES where email=?";
	private static final String SELECTEMPDETAILS= "SELECT * FROM EMPLOYEES where email=?";
	private static final String SELECTDEPTNAME= "SELECT DEPARTMENT_NAME FROM DEPARTMENTS where DEPARTMENT_ID=?";
	private static final String SELECTJOBNAME= "SELECT JOB_TITLE FROM JOBS where JOB_ID=?";
	private static final String UPDATE= "update employees set FIRST_NAME=?,LAST_NAME=?,EMAIL=?,PHONE_NUMBER=?,JOB_ID=?,SALARY=?,COMMISSION_PCT=?,MANAGER_ID=?,DEPARTMENT_ID=? where EMPLOYEE_ID=?";
	private static final String SELECTTOTALEMP= "SELECT count(*) FROM EMPLOYEES";
	private static final String SELECTTOTALREGION= "SELECT count(*) FROM REGIONS";
	private static final String SELECTALLEMPLOYEES= "select employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,commission_pct,manager_id,department_id from EMPLOYEES";
	private static final String DATAFORCSV= "select employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,commission_pct,manager_id,department_id from EMPLOYEES";
	
	private Connection getConnection() throws ClassNotFoundException, SQLException {
			Class.forName(DRIVER_NAME);
			return DriverManager.getConnection(DB_URL, ID, PASS);
		
	}
	
	private static void close(Connection con) throws SQLException {
		if (con != null) {
			con.close();
		}
	}
	
	private static void close(Statement stmt) throws Exception {
		if (stmt != null) {
			stmt.close();
			
		}
		}
	
	public int delete(int id) throws Exception {
		Connection conn = null;
		PreparedStatement stmt = null;
		conn = getConnection();
		stmt = conn.prepareStatement(DELETE);
		stmt.setInt(1, id);
		/*close(stmt);
		close(conn);*/			
		return stmt.executeUpdate();
	}

	public int insert(Employee user) throws Exception{
		Connection conn = null;
		PreparedStatement stmt = null;
		
		
			conn = getConnection();
			stmt = conn.prepareStatement(INSERT);
			stmt.setInt(1, user.getEmployeeId());
			stmt.setString(2, user.getFirstName());
			stmt.setString(3, user.getLastName());
			stmt.setString(4, user.getEmail());
			stmt.setString(5, user.getEmp_phoneno());
			stmt.setString(6, user.getHire_date());
			stmt.setString(7, user.getEmp_jobtype());
			stmt.setFloat(8, user.getEmp_salary());
			stmt.setFloat(9, user.getEmp_commission());
			stmt.setInt(10, user.getEmp_managerid());
			stmt.setInt(11, user.getEmp_dept());
			stmt.setString(12, user.getEmp_password());
			stmt.setInt(13, user.getEmp_type());
			
			int result = stmt.executeUpdate();
			ResultSet rs = stmt.getGeneratedKeys();
			
			if (rs.next()) {
				user.setEmployeeId(rs.getInt(1));
			}
		/*	close(stmt);
			close(conn);*/
			return result;
	}
	
	public ArrayList<String> fetchDepartment() throws Exception{
		ArrayList<String> deptNames = new ArrayList<String>();
		Connection conn = null;
		Statement stmt = null;
		conn = getConnection();
		stmt = conn.createStatement();
		
		ResultSet rs = stmt.executeQuery(SELECTDEPT);
		while(rs.next()) {
			deptNames.add(rs.getString(1));
		}
		
		return deptNames;
	}
	
	public ArrayList<String> fetchJobs() throws Exception{
		ArrayList<String> jobNames = new ArrayList<String>();
		Connection conn = null;
		Statement stmt = null;
		conn = getConnection();
		stmt = conn.createStatement();
		
		ResultSet rs = stmt.executeQuery(SELECTJOBS);
		while(rs.next()) {
			jobNames.add(rs.getString(1));
		}
		return jobNames;
	}

	
	public int fetchDepartmentID(String deptName) throws Exception {
		Connection conn = null;
		PreparedStatement stmt = null;
		int dID=0;
		conn = getConnection();
		stmt = conn.prepareStatement(SELECTDEPTID);
		stmt.setString(1, deptName);
			
			ResultSet rs =stmt.executeQuery();
			while(rs.next())
			{
				dID=rs.getInt(1);
			}
			
			return dID;
	}

	
	public String fetchJobID(String jobName) throws Exception {
		Connection conn = null;
		PreparedStatement stmt = null;
		String jID="";
		conn = getConnection();
		stmt = conn.prepareStatement(SELECTJOBID);
		stmt.setString(1, jobName);
			
			ResultSet rs =stmt.executeQuery();
			while(rs.next())
			{
				jID=rs.getString(1);
			}
			
			return jID;
	}
	
	public int fetchUser(int id) throws Exception {
		Connection conn = null;
		PreparedStatement stmt = null;
		int returnUserId=0;
		conn = getConnection();
		stmt = conn.prepareStatement(SELECTUSERID);
		stmt.setInt(1, id);			
		ResultSet rs = stmt.executeQuery();
		if(rs.next()) {
			returnUserId = rs.getInt(1);
		}
		return returnUserId;
	}

	
	public int fetchLoginUser(String email, String password1) throws Exception {
		Connection conn = null;
		PreparedStatement stmt = null;
		String returnpassword="";
		conn = getConnection();
		stmt = conn.prepareStatement(SELECTLOGINID);
		stmt.setString(1, email);
		ResultSet rs = stmt.executeQuery();
		if (rs.next()) {
			returnpassword = rs.getString(1);
			AESEncyption aes = new AESEncyption();
			String dbpw= aes.decrypt(returnpassword);
			/*System.out.println(dbpw);*/
			if(dbpw.equals(password1)) {
				return 1;
			}
			else
			{
				return 0;
			}
			
		}
		else {
			return 0;
		}
		
	}

	public int fetchEmpType(String type) throws Exception {
		Connection conn = null;
		PreparedStatement stmt = null;
		int returnUserId=0;
		conn = getConnection();
		stmt = conn.prepareStatement(SELECTEMPTYPE);
		stmt.setString(1, type);			
		ResultSet rs = stmt.executeQuery();
		if(rs.next()) {
			returnUserId = rs.getInt(1);
		}
		return returnUserId;
	}

	public Employee fetchEmployee(String email) throws Exception {
		Connection conn = null;
		PreparedStatement stmt = null;
		Employee e= new Employee();
		conn = getConnection();
		stmt = conn.prepareStatement(SELECTEMPDETAILS);
		stmt.setString(1, email);			
		
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			e.setEmployeeId(rs.getInt("EMPLOYEE_ID"));
			e.setFirstName(rs.getString("FIRST_NAME"));
			e.setLastName(rs.getString("LAST_NAME"));
			e.setEmail(rs.getString("EMAIL"));
			e.setEmp_phoneno(rs.getString("PHONE_NUMBER"));
			e.setHire_date(rs.getString("HIRE_DATE"));
			e.setEmp_jobtype(rs.getString("JOB_ID"));
			e.setEmp_salary(rs.getFloat("SALARY"));
			e.setEmp_commission(rs.getFloat("COMMISSION_PCT"));
			e.setEmp_managerid(rs.getInt("MANAGER_ID"));
			e.setEmp_dept(rs.getInt("DEPARTMENT_ID"));
		}
		return e;
		
	}

	public String fetchDepartmentName(int deptID) throws Exception {
		Connection conn = null;
		PreparedStatement stmt = null;
		String Dname="";
		conn = getConnection();
		stmt = conn.prepareStatement(SELECTDEPTNAME);
		stmt.setInt(1, deptID);
			
			ResultSet rs =stmt.executeQuery();
			while(rs.next())
			{
				Dname=rs.getString(1);
			}
			
			return Dname;
	}

	public String fetchJobName(String jobID) throws Exception {
		Connection conn = null;
		PreparedStatement stmt = null;
		String jname="";
		conn = getConnection();
		stmt = conn.prepareStatement(SELECTJOBNAME);
		stmt.setString(1, jobID);
			
			ResultSet rs =stmt.executeQuery();
			while(rs.next())
			{
				jname=rs.getString(1);
			}
			
			return jname;
	}

	
	public int UpdateEmployee(Employee emp) throws Exception {
			Connection conn = null;
			PreparedStatement stmt = null;
			conn = getConnection();
			
			stmt = conn.prepareStatement(UPDATE);
			stmt.setString(1, emp.getFirstName());
			stmt.setString(2, emp.getLastName());
			stmt.setString(3, emp.getEmail());
			stmt.setString(4, emp.getEmp_phoneno());
			stmt.setString(5, emp.getEmp_jobtype());
			stmt.setFloat(6, emp.getEmp_salary());
			stmt.setFloat(7, emp.getEmp_commission());
			stmt.setInt(8, emp.getEmp_managerid());
			stmt.setInt(9, emp.getEmp_dept());
			stmt.setInt(10, emp.getEmployeeId());
			int result = stmt.executeUpdate();
			ResultSet rs = stmt.getGeneratedKeys();
			
			if (rs.next()) {
				emp.setEmployeeId(rs.getInt(1));
			}
			return result;
	}

	public int selecttotalEmployees() throws Exception {
		int count=0;
		Connection conn = null;
		Statement stmt = null;
		conn = getConnection();
		stmt = conn.createStatement();
		
		ResultSet rs = stmt.executeQuery(SELECTTOTALEMP);
		while(rs.next()) {
			count=rs.getInt(1);
		}
		return count;
	}


	public int selecttotalRegions() throws Exception {
		int count=0;
		Connection conn = null;
		Statement stmt = null;
		conn = getConnection();
		stmt = conn.createStatement();
		
		ResultSet rs = stmt.executeQuery(SELECTTOTALREGION);
		while(rs.next()) {
			count=rs.getInt(1);
		}
		return count;
	}

	
	public ArrayList<Employee> fetchEmployeeTabe() throws Exception {
		ArrayList<Employee> allemployees = new ArrayList<Employee>();
		Connection conn = null;
		PreparedStatement stmt = null;
		
		conn = getConnection();
		stmt = conn.prepareStatement(SELECTALLEMPLOYEES);			
		
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			Employee e= new Employee();
			e.setEmployeeId(rs.getInt("EMPLOYEE_ID"));
			e.setFirstName(rs.getString("FIRST_NAME"));
			e.setLastName(rs.getString("LAST_NAME"));
			e.setEmail(rs.getString("EMAIL"));
			e.setEmp_phoneno(rs.getString("PHONE_NUMBER"));
			e.setHire_date(rs.getString("HIRE_DATE"));
			e.setEmp_jobtype(rs.getString("JOB_ID"));
			e.setEmp_salary(rs.getFloat("SALARY"));
			e.setEmp_commission(rs.getFloat("COMMISSION_PCT"));
			e.setEmp_managerid(rs.getInt("MANAGER_ID"));
			e.setEmp_dept(rs.getInt("DEPARTMENT_ID"));
			allemployees.add(e);
			
		}
		return allemployees;
	}


	public void exportCSV() throws Exception {
		Connection conn = null;
		Statement stmt = null;
		
		conn = getConnection();
		stmt = conn.createStatement();
		ResultSet query_set = stmt.executeQuery(DATAFORCSV);
		
		FileWriter my_csv=new FileWriter("C:\\Users\\mvinay\\Desktop\\out.csv");
        CSVWriter my_csv_output=new CSVWriter(my_csv); 
        boolean includecolumnnames=true;
        my_csv_output.writeAll(query_set,includecolumnnames);
        my_csv_output.close();
	}

	
	public int uploadCSV(ArrayList<Employee> ar) throws Exception {
			Connection conn = null;
			PreparedStatement stmt = null;
			int result = 0;
		
			conn = getConnection();
			stmt = conn.prepareStatement(INSERT);
			for(Employee user: ar) {
				
				stmt.setInt(1, user.getEmployeeId());
				stmt.setString(2, user.getFirstName());
				stmt.setString(3, user.getLastName());
				stmt.setString(4, user.getEmail());
				stmt.setString(5, user.getEmp_phoneno());
				stmt.setString(6, user.getHire_date());
				stmt.setString(7, user.getEmp_jobtype());
				stmt.setFloat(8, user.getEmp_salary());
				stmt.setFloat(9, user.getEmp_commission());
				stmt.setInt(10, user.getEmp_managerid());
				stmt.setInt(11, user.getEmp_dept());
				stmt.setString(12, user.getEmp_password());
				stmt.setInt(13, user.getEmp_type());
				
				result = stmt.executeUpdate();
				ResultSet rs = stmt.getGeneratedKeys();
			
			}
		return result;
	}
}

